package com.example.controller;

public @interface Autowired {

}
