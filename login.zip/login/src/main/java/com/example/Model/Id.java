package com.example.Model;

public @interface Id {

}
